<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'pprfvlmy_selfass');
define('DB_USER', 'pprfvlmy_selfass');
define('DB_PASS', '');

define('SITE_URL', 'https://www.feltandyarn.com/clients/assessment/');
